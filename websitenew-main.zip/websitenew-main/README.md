website, fixed pricing model
